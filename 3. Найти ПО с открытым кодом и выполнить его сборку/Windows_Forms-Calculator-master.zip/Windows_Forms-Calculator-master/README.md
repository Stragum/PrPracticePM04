# Windows Forms-Calculator
Простой калькулятор со всеми основными функциями, который написан на C#
![Screenshot](screenshot.jpg)
